<?php
include('library.php');

$client = new cdClient();
$client->request();
$client->initHeaders();

echo $client->getContent();
